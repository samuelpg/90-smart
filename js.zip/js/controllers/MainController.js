/* app.controller('MainController',['$scope',function($scope){
    $scope.images{
        ["1.gif",
         "2.gif",
         "3.gif",
         "4.gif",
         "5.gif",
         "6.gif",
         "7.gif",
         "8.gif",]
    }
    $scope.photo = function() {
        $scope.image = 'C:\Users\Samuel Parra\Documents\90-smart\pictures' + images[Math.floor(Math.random() * images.length)];
    };
    $scope.unphoto = function() {
        $scope.image = "";
    };
}]); */

//'C:\Users\Samuel Parra\Documents\90-smart\pictures' + gifs[ Math.floor(Math.random * gifs.length)];