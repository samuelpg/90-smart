var app = angular.module("myApp", []);

app.controller('MainController', ['$scope', function ($scope) {
   var images = ["1.gif", "2.gif", "3.gif", "4.gif", "5.gif", "6.gif", "7.gif", "8.gif"];
    
    $scope.photo = function () {
        $scope.image = 'pictures/' + Math.floor((Math.random() * 12) + 1).toString() + ".gif";
    };
    $scope.unphoto = function () {
        $scope.image = " ";
    };
}]);